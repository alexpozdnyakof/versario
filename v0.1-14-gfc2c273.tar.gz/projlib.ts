function sum(x: number, y: number){
  return x + y
}

function multiply(x: number, y: number){
  return x * y
}

function divide(x: number, y: number){
  return x/y
}

export { sum } 
